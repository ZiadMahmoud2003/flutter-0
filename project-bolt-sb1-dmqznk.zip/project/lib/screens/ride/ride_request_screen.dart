import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:ride_hailing_app/services/location_service.dart';
import 'package:ride_hailing_app/services/ride_service.dart';

class RideRequestScreen extends StatefulWidget {
  const RideRequestScreen({super.key});

  @override
  State<RideRequestScreen> createState() => _RideRequestScreenState();
}

class _RideRequestScreenState extends State<RideRequestScreen> {
  final LocationService _locationService = LocationService();
  final RideService _rideService = RideService();
  final TextEditingController _destinationController = TextEditingController();
  LatLng? _pickupLocation;
  LatLng? _destinationLocation;

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
  }

  Future<void> _getCurrentLocation() async {
    try {
      final location = await _locationService.getLatLng();
      setState(() {
        _pickupLocation = location;
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    }
  }

  Future<void> _requestRide() async {
    if (_pickupLocation == null || _destinationLocation == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select pickup and destination locations')),
      );
      return;
    }

    try {
      await _rideService.createRideRequest(
        userId: 'current-user-id', // TODO: Get from AuthService
        pickup: _pickupLocation!,
        destination: _destinationLocation!,
        estimatedFare: 20.0, // TODO: Calculate based on distance
      );

      if (!mounted) return;
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Request Ride'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _destinationController,
              decoration: const InputDecoration(
                labelText: 'Where to?',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.location_on),
              ),
              onSubmitted: (value) {
                // TODO: Implement location search and selection
              },
            ),
            const SizedBox(height: 16),
            if (_pickupLocation != null)
              Text(
                'Pickup: ${_pickupLocation!.latitude}, ${_pickupLocation!.longitude}',
                style: Theme.of(context).textTheme.bodyLarge,
              ),
            const Spacer(),
            ElevatedButton(
              onPressed: _requestRide,
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
              child: const Text('Request Ride'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _destinationController.dispose();
    super.dispose();
  }
}