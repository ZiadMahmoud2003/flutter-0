import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String id;
  final String phoneNumber;
  final String? name;
  final String? profilePicture;
  final double? rating;
  final int ridesCompleted;

  UserModel({
    required this.id,
    required this.phoneNumber,
    this.name,
    this.profilePicture,
    this.rating,
    this.ridesCompleted = 0,
  });

  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel(
      id: doc.id,
      phoneNumber: data['phoneNumber'] ?? '',
      name: data['name'],
      profilePicture: data['profilePicture'],
      rating: (data['rating'] ?? 0.0).toDouble(),
      ridesCompleted: data['ridesCompleted'] ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'phoneNumber': phoneNumber,
      'name': name,
      'profilePicture': profilePicture,
      'rating': rating,
      'ridesCompleted': ridesCompleted,
    };
  }
}