import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class RideModel {
  final String id;
  final String userId;
  final String? driverId;
  final GeoPoint pickup;
  final GeoPoint destination;
  final String status;
  final double estimatedFare;
  final DateTime createdAt;
  final DateTime? updatedAt;

  RideModel({
    required this.id,
    required this.userId,
    this.driverId,
    required this.pickup,
    required this.destination,
    required this.status,
    required this.estimatedFare,
    required this.createdAt,
    this.updatedAt,
  });

  factory RideModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return RideModel(
      id: doc.id,
      userId: data['userId'],
      driverId: data['driverId'],
      pickup: data['pickup'] as GeoPoint,
      destination: data['destination'] as GeoPoint,
      status: data['status'],
      estimatedFare: data['estimatedFare'].toDouble(),
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      updatedAt: data['updatedAt'] != null 
          ? (data['updatedAt'] as Timestamp).toDate()
          : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'driverId': driverId,
      'pickup': pickup,
      'destination': destination,
      'status': status,
      'estimatedFare': estimatedFare,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': updatedAt != null ? Timestamp.fromDate(updatedAt!) : null,
    };
  }

  LatLng get pickupLatLng => LatLng(pickup.latitude, pickup.longitude);
  LatLng get destinationLatLng => LatLng(destination.latitude, destination.longitude);
}