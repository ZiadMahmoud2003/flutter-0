import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class RideService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> createRideRequest({
    required String userId,
    required LatLng pickup,
    required LatLng destination,
    required double estimatedFare,
  }) async {
    await _firestore.collection('rides').add({
      'userId': userId,
      'status': 'pending',
      'pickup': GeoPoint(pickup.latitude, pickup.longitude),
      'destination': GeoPoint(destination.latitude, destination.longitude),
      'estimatedFare': estimatedFare,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot> getRideRequests() {
    return _firestore
        .collection('rides')
        .where('status', isEqualTo: 'pending')
        .snapshots();
  }

  Future<void> updateRideStatus(String rideId, String status) async {
    await _firestore.collection('rides').doc(rideId).update({
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
}