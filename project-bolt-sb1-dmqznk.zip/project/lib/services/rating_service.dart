import 'package:cloud_firestore/cloud_firestore.dart';

class RatingService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> submitRating({
    required String rideId,
    required String userId,
    required String driverId,
    required double rating,
    String? comment,
  }) async {
    final batch = _firestore.batch();

    // Add rating document
    final ratingRef = _firestore.collection('ratings').doc();
    batch.set(ratingRef, {
      'rideId': rideId,
      'userId': userId,
      'driverId': driverId,
      'rating': rating,
      'comment': comment,
      'timestamp': FieldValue.serverTimestamp(),
    });

    // Update driver's average rating
    final driverRatings = await _firestore
        .collection('ratings')
        .where('driverId', isEqualTo: driverId)
        .get();

    double totalRating = driverRatings.docs.fold(
      0.0,
      (sum, doc) => sum + (doc.data()['rating'] as num).toDouble(),
    );
    totalRating += rating;
    
    final newAverageRating = totalRating / (driverRatings.size + 1);
    
    batch.update(
      _firestore.collection('users').doc(driverId),
      {'rating': newAverageRating},
    );

    await batch.commit();
  }

  Stream<QuerySnapshot> getDriverRatings(String driverId) {
    return _firestore
        .collection('ratings')
        .where('driverId', isEqualTo: driverId)
        .orderBy('timestamp', descending: true)
        .snapshots();
  }
}