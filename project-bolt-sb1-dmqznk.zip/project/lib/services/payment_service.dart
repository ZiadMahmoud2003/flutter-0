import 'package:cloud_firestore/cloud_firestore.dart';

class PaymentService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> processPayment({
    required String rideId,
    required String userId,
    required double amount,
    required String paymentMethod,
  }) async {
    try {
      // TODO: Integrate with actual payment gateway
      await _firestore.collection('payments').add({
        'rideId': rideId,
        'userId': userId,
        'amount': amount,
        'paymentMethod': paymentMethod,
        'status': 'completed',
        'timestamp': FieldValue.serverTimestamp(),
      });

      await _firestore
          .collection('rides')
          .doc(rideId)
          .update({'paymentStatus': 'completed'});
    } catch (e) {
      throw Exception('Payment failed: $e');
    }
  }

  Future<Map<String, dynamic>> getRidePaymentStatus(String rideId) async {
    final payment = await _firestore
        .collection('payments')
        .where('rideId', isEqualTo: rideId)
        .get();
    
    if (payment.docs.isEmpty) {
      return {'status': 'pending'};
    }
    
    return payment.docs.first.data();
  }
}