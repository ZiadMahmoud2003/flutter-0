import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:math' show cos, sqrt, asin;

class LocationUtils {
  static double calculateDistance(LatLng start, LatLng end) {
    const p = 0.017453292519943295; // Math.PI / 180
    final lat1 = start.latitude;
    final lon1 = start.longitude;
    final lat2 = end.latitude;
    final lon2 = end.longitude;

    final a = 0.5 -
        cos((lat2 - lat1) * p) / 2 +
        cos(lat1 * p) * cos(lat2 * p) * (1 - cos((lon2 - lon1) * p)) / 2;

    return 12742 * asin(sqrt(a)); // 2 * R; R = 6371 km
  }

  static double calculateEstimatedFare(double distanceInKm) {
    const basePrice = 5.0; // Base fare
    const pricePerKm = 2.0; // Price per kilometer
    return basePrice + (distanceInKm * pricePerKm);
  }

  static String formatDistance(double distanceInKm) {
    if (distanceInKm < 1) {
      return '${(distanceInKm * 1000).toStringAsFixed(0)}m';
    }
    return '${distanceInKm.toStringAsFixed(1)}km';
  }
}